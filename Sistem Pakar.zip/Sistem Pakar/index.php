<?php
include 'header.php';
?>
<br>
<?php
include 'pil_gejala.php';
include 'footer.php';
 ?>
