<br>
<div class="jombotron" >
	<footer class="bottom" style="background: #1e252f;color: #fff;">
    	<div class="footer-copyright py-3">
        	<span>
            	<a>
              		<em>&copy; 2021 Copyright: Sistem Pakar</em>
            	</a>
          	</span>
          	<li class="footer-copyright py-0" style="float:right">Kelompok CTRL CV</a>
                    </li>
               
		</div>
  	</footer>
</div>

</body>
</html>
