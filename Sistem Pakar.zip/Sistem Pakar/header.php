<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>DIAGNOSA COVID-19</title>
  </head>
  <body>
    <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand" href="index.php">
        <img src="home.svg" width="30" height="30" class="d-inline-block align-top" alt="">HOME
      </a>
      <a class="navbar-brand" href="aboutus.php">
        <img src="1.png" width="30" height="30" class="d-inline-block align-top" alt="">ABOUT US
      </a>
      <h4>Sistem Pakar Diagnosa COVID 19 Berbasis WEB KELOMPOK CTRL CV</h4>
    </nav>
