# Aplikasi-Kecerdasan-Buatan
Sistem Pakar Diagnosa Penyakit Tanaman Padi Berbasis WEB Dengan Forward dan Backward Chaining

#term to use
1. pastikan import database terlebih dahulu sebelum menggunakan
2. data yang ada berdasarkan jurnal yang tertera
