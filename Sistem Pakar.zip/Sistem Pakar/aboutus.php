<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="bootstrap.min.js"></script>
    <title>DIAGNOSA COVID-19</title>
  </head>
  <body>
    <nav class="navbar navbar-light bg-light">
      <a class="navbar-brand" href="index.php">
        <img src="home.svg" width="30" height="30" class="d-inline-block align-top" alt="">HOME
      </a>
      <a class="navbar-brand" href="aboutus.php">
        <img src="1.png" width="30" height="30" class="d-inline-block align-top" alt="">ABOUT US
      </a>
      <h4>Sistem Pakar Diagnosa COVID 19 Berbasis WEB KELOMPOK CTRL CV</h4>
    </nav>

    <div class="container">
            <div class="col-md-6">
              <p align="justify">WEBSITE ini dibuat untuk melaksanakan Tugas Akhir Sistem Pakar.</p>
              <p align="justify">Nama Anggota Kelompok</p>
              <p align="justify">Muhammad Bagas Pangestu - 00000032962</p>
              <p align="justify">Araffi Luthfian Harits - 00000033232</p>
              <p align="justify">Rafi Suryadani - 00000032986</p>
              <div class="item">
              <img src="<?php echo base_url('theme/user/images/hotel1.jpg');?>" alt="...">
                </div>
            </div>
          </div>
            </div>
            
            <div class="clearfix"></div>
    </div>
<?php $this->load->view('footer'); ?>
